import os
from PyPDF2 import PdfMerger


from PIL import Image

output_dir = (os.path.join(os.getcwd(), "output"))
image_dir = (os.path.join(os.getcwd(), "temp"))


def del_file(dir):
    # Delete the files in directories
    for filename in os.listdir(dir):
        filepath = os.path.join(dir, filename)
        if not filepath:
            continue
        os.remove(filepath)


def img_pdf():
    del_file(output_dir)

    # Create an image object for each image file
    images = [Image.open(os.path.join(image_dir, filename)) for filename in os.listdir(image_dir)]
    # Iterate over the images in groups of 8
    for i in range(0, len(images), 6):
        # Calculate the size of the output image
        spacing = 30
        margin = 50
        width = 2 * (images[0].width + spacing) - spacing + 2 * margin
        height = 4 * (images[0].height + spacing) - spacing + 2 * margin

        # Create a blank image with a white background
        page = Image.new('RGB', (width, height), 'white')

        # Paste the images into the page
        for j in range(6):
            if i + j >= len(images):
                break
            x = j % 2
            y = j // 2
            page.paste(images[i + j], (x * (images[0].width + spacing) + margin, y * (images[0].height + spacing) + margin))

        # Save the page to a PDF file
        page.save('{}/output_{}.pdf'.format(output_dir, i), 'PDF', resolution=300.0, quality=95)
    del_file(image_dir)


def merge_pdf():
    img_pdf()
    # Create a PDF file merger
    merger = PdfMerger()

    # Loop through the PDF files in the directory
    for filename in os.listdir(output_dir):
        # Skip non-PDF files
        if not filename.endswith('.pdf'):
            continue

        # Add the PDF file to the merger
        filepath = os.path.join(output_dir, filename)
        merger.append(filepath)

    # Save the merged PDF file
    merged_filepath = os.path.join(output_dir, 'merged.pdf')
    merger.write(merged_filepath)
    # Close the merger
    merger.close()

    for filename in os.listdir(output_dir):
        if filename.endswith('.pdf') and filename != 'merged.pdf':
            filepath = os.path.join(output_dir, filename)
            os.remove(filepath)



